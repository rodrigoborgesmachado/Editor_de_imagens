Editor de imagens que tem o objetivo de redimensionar imagens e retirar o fundo delas.
O software possibilita também a conversão do arquivo para qualquer extensão diferente de imagens.
Há ainda a pasta de imagens com alguns ícones para testes.

Qualquer dúvida entre em contato: rodrigoborgesmachado@gmail.com
Link do repositório do projeto: https://github.com/rodrigoborgesmachado/Editor_de_imagens.git